(function(){
  'use strict';
  const doc = document;
  const root = doc.documentElement;
  const body = doc.body;
  const cfg = window.ETEHADYAR_CONFIG || {};

  // Header & Nav
  const langButton = doc.getElementById('lang-toggle');
  const menuButton = doc.getElementById('menu-toggle');
  const mobileMenu = doc.getElementById('mobile-menu');
  const header = doc.getElementById('site-header');
  const progress = doc.querySelector('.scroll-progress');
  const glow = doc.querySelector('.ambient-glow');

  // Pricing & Tour
  const currencyButtons = Array.from(doc.querySelectorAll('[data-currency]'));
  const currencyPanels = Array.from(doc.querySelectorAll('[data-price-panel]'));
  const tourButtons = Array.from(doc.querySelectorAll('[data-tour]'));
  const tourPanels = Array.from(doc.querySelectorAll('[data-tour-panel]'));
  const lightbox = doc.getElementById('lightbox');
  const lightboxImage = doc.getElementById('lightbox-image');
  let currencyTouched = false;

  body.classList.add('js-ready');

  function toFaNumber(value){
    return String(value).replace(/\d/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; });
  }

  function formatToman(num){
    return toFaNumber(num.toLocaleString('fa-IR'));
  }

  function getStored(key, fallback){
    try { return localStorage.getItem(key) || fallback; } catch(e){ return fallback; }
  }

  function store(key, value){
    try { localStorage.setItem(key, value); } catch(e){}
  }

  function buyUrl(currency){
    return currency === 'usd'
      ? (cfg.purchaseUrlInternational || cfg.purchaseUrlIR || 'https://etehadyar.ir/')
      : (cfg.purchaseUrlIR || cfg.purchaseUrlInternational || 'https://etehadyar.ir/');
  }

  function applyConfig(){
    doc.querySelectorAll('[data-price-irr]').forEach(function(el){ el.textContent = cfg.priceToman || '۱۵٬۰۰۰٬۰۰۰'; });
    doc.querySelectorAll('[data-price-usd]').forEach(function(el){ el.textContent = cfg.priceUSD || '150'; });
    doc.querySelectorAll('[data-version]').forEach(function(el){ el.textContent = cfg.currentVersion || '6.12.0'; });
  }

  function setCurrency(currency, persist){
    const chosen = currency === 'usd' ? 'usd' : 'irr';
    root.dataset.currency = chosen;
    currencyButtons.forEach(function(button){
      const active = button.dataset.currency === chosen;
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
    });
    currencyPanels.forEach(function(panel){
      panel.hidden = panel.dataset.pricePanel !== chosen;
    });
    doc.querySelectorAll('[data-buy]').forEach(function(link){
      link.href = buyUrl(chosen);
    });
    if(persist) store('etehadyar-currency', chosen);
  }

  function setLanguage(lang, initial){
    const en = lang === 'en';
    root.dataset.lang = en ? 'en' : 'fa';
    root.lang = en ? 'en' : 'fa';
    root.dir = en ? 'ltr' : 'rtl';
    const ver = cfg.currentVersion || '6.12';
    doc.title = en
      ? 'Etehadyar ' + ver + ' — AI WordPress Operating System'
      : 'اتحادیار ' + ver + ' — سیستم‌عامل هوشمند وردپرس';
    if(langButton) langButton.setAttribute('aria-label', en ? 'تغییر زبان به فارسی' : 'Switch to English');
    if(menuButton) menuButton.setAttribute('aria-label', en ? 'Open menu' : 'باز کردن منو');
    store('etehadyar-lang', en ? 'en' : 'fa');
    if(!currencyTouched){
      const saved = initial ? getStored('etehadyar-currency', '') : '';
      setCurrency(saved || (en ? 'usd' : 'irr'), false);
    }
  }

  applyConfig();
  setLanguage(getStored('etehadyar-lang', 'fa') === 'en' ? 'en' : 'fa', true);
  if(langButton){
    langButton.addEventListener('click', function(){
      setLanguage(root.dataset.lang === 'fa' ? 'en' : 'fa', false);
    });
  }

  currencyButtons.forEach(function(button, index){
    button.addEventListener('click', function(){
      currencyTouched = true;
      setCurrency(button.dataset.currency, true);
    });
    button.addEventListener('keydown', function(event){
      if(!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const dir = event.key === 'ArrowRight' ? 1 : -1;
      const next = (index + dir + currencyButtons.length) % currencyButtons.length;
      currencyTouched = true;
      setCurrency(currencyButtons[next].dataset.currency, true);
      currencyButtons[next].focus();
    });
  });

  function closeMenu(){
    if(!mobileMenu) return;
    mobileMenu.classList.remove('open');
    if(menuButton) menuButton.setAttribute('aria-expanded', 'false');
    body.classList.remove('menu-open');
  }

  if(menuButton && mobileMenu){
    menuButton.addEventListener('click', function(){
      const open = !mobileMenu.classList.contains('open');
      mobileMenu.classList.toggle('open', open);
      menuButton.setAttribute('aria-expanded', String(open));
      body.classList.toggle('menu-open', open);
    });
    mobileMenu.querySelectorAll('a').forEach(function(link){
      link.addEventListener('click', closeMenu);
    });
    doc.addEventListener('click', function(event){
      if(!event.target.closest('.nav-shell')) closeMenu();
    });
  }

  // Workspaces Tour Tabs
  function activateTour(name, focus){
    tourButtons.forEach(function(button){
      const active = button.dataset.tour === name;
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
      if(active && focus) button.focus();
    });
    tourPanels.forEach(function(panel){
      panel.hidden = panel.dataset.tourPanel !== name;
    });
  }

  tourButtons.forEach(function(button, index){
    button.addEventListener('click', function(){
      activateTour(button.dataset.tour, false);
    });
    button.addEventListener('keydown', function(event){
      if(!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const dir = event.key === 'ArrowRight' ? 1 : -1;
      const next = (index + dir + tourButtons.length) % tourButtons.length;
      activateTour(tourButtons[next].dataset.tour, true);
    });
  });

  // Lightbox Modal
  function openLightbox(src, alt){
    if(!lightbox || !lightboxImage) return;
    lightboxImage.src = src;
    lightboxImage.alt = alt || '';
    lightbox.hidden = false;
    body.classList.add('lightbox-open');
    const closeBtn = doc.querySelector('.lightbox-close');
    if(closeBtn) closeBtn.focus();
  }

  function closeLightbox(){
    if(!lightbox || !lightboxImage) return;
    lightbox.hidden = true;
    lightboxImage.src = '';
    body.classList.remove('lightbox-open');
  }

  doc.querySelectorAll('[data-lightbox]').forEach(function(button){
    button.addEventListener('click', function(){
      openLightbox(button.dataset.lightbox, button.querySelector('img')?.alt);
    });
  });

  if(lightbox){
    lightbox.addEventListener('click', function(event){
      if(event.target === lightbox || event.target.closest('.lightbox-close')) closeLightbox();
    });
  }

  // Header Scroll & Progress Bar
  function onScroll(){
    const y = window.scrollY || 0;
    if(header) header.classList.toggle('scrolled', y > 32);
    const height = doc.documentElement.scrollHeight - window.innerHeight;
    const amount = height > 0 ? Math.min(100, Math.max(0, y / height * 100)) : 0;
    if(progress) progress.style.setProperty('--scroll', amount + '%');
  }
  onScroll();
  window.addEventListener('scroll', onScroll, {passive: true});

  doc.addEventListener('keydown', function(event){
    if(event.key === 'Escape'){
      closeMenu();
      if(lightbox && !lightbox.hidden) closeLightbox();
    }
  });

  // Reveal Animations
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!reduced && 'IntersectionObserver' in window){
    const observer = new IntersectionObserver(function(entries, obs){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, {threshold: 0.08, rootMargin: '0px 0px -28px'});
    doc.querySelectorAll('.reveal').forEach(function(el){ observer.observe(el); });
  } else {
    doc.querySelectorAll('.reveal').forEach(function(el){ el.classList.add('is-visible'); });
  }

  // ScrollSpy for Nav & Story Progress
  if('IntersectionObserver' in window){
    const links = Array.from(doc.querySelectorAll('.desktop-nav a[href^="#"], .story-nav a[href^="#"]'));
    const map = new Map(links.map(function(link){ return [link.getAttribute('href').slice(1), link]; }));
    const navObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting && map.has(entry.target.id)){
          links.forEach(function(link){
            if(link.getAttribute('href') === '#' + entry.target.id){
              link.classList.add('active');
            } else {
              link.classList.remove('active');
            }
          });
        }
      });
    }, {rootMargin: '-30% 0px -50%', threshold: 0});

    ['top', 'story-chaos', 'story-core', 'voice', 'factory', 'queue', 'tour', 'calculator', 'features', 'pricing'].forEach(function(id){
      const el = doc.getElementById(id);
      if(el) navObserver.observe(el);
    });
  }

  // Cursor Ambient Glow
  if(!reduced && glow && window.matchMedia('(pointer:fine)').matches){
    window.addEventListener('pointermove', function(event){
      glow.style.setProperty('--mx', event.clientX + 'px');
      glow.style.setProperty('--my', event.clientY + 'px');
    }, {passive: true});
  }

  /* ========================================================================
     3D CARD TILT PARALLAX EFFECT
     ======================================================================== */
  if(!reduced && window.matchMedia('(pointer:fine)').matches){
    const tiltCards = Array.from(doc.querySelectorAll('.tilt-3d'));
    tiltCards.forEach(function(card){
      card.addEventListener('mousemove', function(e){
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -10;
        const rotateY = ((x - centerX) / centerX) * 10;
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
      });
      card.addEventListener('mouseleave', function(){
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
      });
    });
  }

    /* ========================================================================
     INTERACTIVE COMPONENT 1: LIVE VOICE ASSISTANT (AUTHENTIC PERSIAN AUDIO)
     ======================================================================== */
  const micButton = doc.getElementById('voice-mic-btn');
  const voiceWaveform = doc.getElementById('voice-waveform');
  const voiceTranscript = doc.getElementById('voice-transcript');
  const voiceReplyBox = doc.getElementById('voice-reply-box');
  const voiceReplyText = doc.getElementById('voice-reply-text');
  const voiceSpeedButtons = Array.from(doc.querySelectorAll('[data-voice-speed]'));
  const voicePromptPills = Array.from(doc.querySelectorAll('[data-voice-prompt]'));
  const stopVoiceBtn = doc.getElementById('stop-voice-btn');
  const voiceStatusLabel = doc.getElementById('voice-status-label');

  let isVoiceActive = false;
  let isListening = false;
  let voiceTimer = null;
  let currentSpeechRate = 1.0;
  let currentAudio = null;
  let recognition = null;

  // Web Audio Tone Feedback (Beep / Chime)
  function playAudioTone(freq, duration, type){
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if(!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type || 'sine';
      osc.frequency.value = freq || 440;
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch(e){}
  }

  const sampleVoiceDialogues = {
    p1: {
      user: "اتحادیار، برای ۵ محصول جدید ساعت هوشمند، توضیحات جذاب، جدول مشخصات و ۳ سناریوی ریلز اینستاگرام آماده کن.",
      ai: "درود بر شما! ۵ عنوان سئو شده، توضیحات تجاری با لحن برند و جدول مشخصات فنی برای ساعت‌های هوشمند تولید و مستقیماً در ووکامرس پیش‌نویس شد. همچنین ۳ سناریوی ویدیویی ریلز همراه با متن روخوانی و زیرنویس فارسی در استودیوی ویدیو آماده دانلود است.",
      audio: "assets/audio/p1_response.mp3"
    },
    p2: {
      user: "وضعیت صف کارهای نامتقارن و سلامت ارتباط با OpenAI و Gemini رو بررسی کن.",
      ai: "گزارش مرکز سلامت: ارتباط با OpenAI با تاخیر ۱۲۰ میلی‌ثانیه و Gemini با ۹۵ میلی‌ثانیه کاملاً پایدار است. هم‌اکنون ۳ تسک در صف پس‌زمینه با موفقیت تکمیل شده و هیچ خطایی ثبت نشده است. شاخص سلامت ۹۸ از ۱۰۰ است.",
      audio: "assets/audio/p2_response.mp3"
    },
    p3: {
      user: "کاربر درباره نحوه ارسال سفارش سوال پرسیده؛ پاسخ با اطمینان ۹۸٪ بده و برای کارشناس یادداشت بذار.",
      ai: "پاسخ هوشمند ارسال شد: سفارش‌های تهران با پیک اختصاصی در کمتر از ۲ ساعت و شهرستان‌ها با پست پیشتاز ظرف ۴۸ ساعت تحویل می‌شوند. درصد اطمینان پاسخ ۹۸ درصد است. فایل صوتی و یادداشت پیگیری نیز به پنل کارشناس الصاق گردید.",
      audio: "assets/audio/p3_response.mp3"
    },
    p4: {
      user: "یک مقاله جامع ۲۰۰۰ کلمه‌ای درباره هوش مصنوعی در سئو همراه با ۳ تصویر Flux تولید کن.",
      ai: "فرآیند تولید محتوا در صف پس‌زمینه آغاز شد. تیترها با ساختار سئو، ممیزی کیفیت، جدول مقایسه، اسکیما و تصاویر اختصاصی Flux تولید و مستقیماً در رسانه وردپرس ذخیره گردید.",
      audio: "assets/audio/p4_response.mp3"
    }
  };

  // Play Native Studio-Recorded Persian Audio
  function playPersianAudio(audioUrl, fallbackText){
    stopVoicePlay();
    isVoiceActive = true;

    try {
      currentAudio = new Audio(audioUrl);
      currentAudio.playbackRate = currentSpeechRate || 1.0;

      currentAudio.onplay = function(){
        if(voiceWaveform) voiceWaveform.classList.add('is-speaking');
        if(voiceStatusLabel) voiceStatusLabel.textContent = "هوش مصنوعی در حال صحبت به زبان فارسی روان است...";
      };

      currentAudio.onended = function(){
        if(voiceWaveform) voiceWaveform.classList.remove('is-speaking');
        if(voiceStatusLabel) voiceStatusLabel.textContent = "گفت‌وگو پایان یافت. آماده دریافت صدای بعدی...";
        isVoiceActive = false;
        currentAudio = null;
      };

      currentAudio.onerror = function(){
        // Fallback to browser speech if audio file fails
        if(voiceWaveform) voiceWaveform.classList.remove('is-speaking');
        isVoiceActive = false;
        currentAudio = null;
      };

      const playPromise = currentAudio.play();
      if(playPromise !== undefined){
        playPromise.catch(function(err){
          console.warn("Audio autoplay policy or error:", err);
          if(voiceWaveform) voiceWaveform.classList.remove('is-speaking');
          isVoiceActive = false;
        });
      }
    } catch(e){
      console.warn("Audio error:", e);
      isVoiceActive = false;
    }
  }

  function stopVoicePlay(){
    if(voiceTimer) clearTimeout(voiceTimer);
    if(currentAudio){
      try {
        currentAudio.pause();
        currentAudio.currentTime = 0;
      } catch(e){}
      currentAudio = null;
    }
    if('speechSynthesis' in window){
      window.speechSynthesis.cancel();
    }
    if(recognition && isListening){
      try { recognition.stop(); } catch(e){}
    }
    isVoiceActive = false;
    isListening = false;
    if(micButton) micButton.classList.remove('is-recording');
    if(voiceWaveform) voiceWaveform.classList.remove('is-speaking', 'is-pulsing');
    if(voiceStatusLabel) voiceStatusLabel.textContent = "صدا متوقف شد (Interrupted). برای شروع دوباره روی میکروفون بزنید.";
    playAudioTone(300, 0.15, 'triangle');
  }

  function simulateVoiceInteraction(promptKey){
    const data = sampleVoiceDialogues[promptKey] || sampleVoiceDialogues.p1;
    if(!voiceTranscript || !voiceReplyBox || !voiceReplyText) return;

    stopVoicePlay();
    isVoiceActive = true;
    playAudioTone(660, 0.12, 'sine');

    if(micButton) micButton.classList.add('is-recording');
    if(voiceWaveform) voiceWaveform.classList.add('is-pulsing');
    if(voiceStatusLabel) voiceStatusLabel.textContent = "در حال گوش دادن به گفتار شما (تشخیص فارسی)...";
    voiceTranscript.textContent = "در حال ضبط گفتار فارسی...";
    voiceReplyBox.classList.remove('is-active');

    // Step 1: Simulate Live Transcript Typing
    voiceTimer = setTimeout(function(){
      playAudioTone(880, 0.08, 'sine');
      voiceTranscript.textContent = "« " + data.user + " »";
      if(micButton) micButton.classList.remove('is-recording');
      if(voiceStatusLabel) voiceStatusLabel.textContent = "در حال پردازش و استخراج پاسخ با ضریب اطمینان ۹۸٪...";
      
      // Step 2: AI Voice Response with Native Persian Studio Audio
      voiceTimer = setTimeout(function(){
        voiceReplyText.textContent = data.ai;
        voiceReplyBox.classList.add('is-active');
        if(voiceWaveform) voiceWaveform.classList.remove('is-pulsing');
        
        // Play the studio Persian audio!
        playPersianAudio(data.audio, data.ai);
      }, 700);
    }, 1100);
  }

  // Real Web Speech Recognition
  function initSpeechRecognition(){
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SpeechRecognition) return false;

    recognition = new SpeechRecognition();
    recognition.lang = 'fa-IR';
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = function(){
      isListening = true;
      isVoiceActive = true;
      playAudioTone(660, 0.1, 'sine');
      if(micButton) micButton.classList.add('is-recording');
      if(voiceWaveform) voiceWaveform.classList.add('is-pulsing');
      if(voiceStatusLabel) voiceStatusLabel.textContent = "میکروفون فعال است؛ صحبت کنید (فارسی)...";
      if(voiceTranscript) voiceTranscript.textContent = "در حال شنیدن صدای شما...";
      if(voiceReplyBox) voiceReplyBox.classList.remove('is-active');
    };

    recognition.onresult = function(event){
      let transcript = '';
      for(let i = event.resultIndex; i < event.results.length; ++i){
        transcript += event.results[i][0].transcript;
      }
      if(voiceTranscript) voiceTranscript.textContent = "« " + transcript + " »";
    };

    recognition.onend = function(){
      isListening = false;
      if(micButton) micButton.classList.remove('is-recording');
      if(voiceWaveform) voiceWaveform.classList.remove('is-pulsing');
      
      const userText = voiceTranscript ? voiceTranscript.textContent.replace(/[«»]/g, '').trim() : '';
      if(userText && userText !== "در حال شنیدن صدای شما..."){
        if(voiceStatusLabel) voiceStatusLabel.textContent = "در حال پردازش گفتار شما در هسته اتحادیار...";
        setTimeout(function(){
          const aiResponse = "درود بر شما! دستور صوتی شما با موفقیت دریافت شد («" + userText + "»). این عملیات در صف کارهای پس‌زمینه وردپرس قرار گرفت و نتیجه به‌زودی در پیشخوان ثبت خواهد شد.";
          if(voiceReplyText) voiceReplyText.textContent = aiResponse;
          if(voiceReplyBox) voiceReplyBox.classList.add('is-active');
          playPersianAudio("assets/audio/custom_response.mp3", aiResponse);
        }, 600);
      } else {
        if(voiceStatusLabel) voiceStatusLabel.textContent = "صدایی شنیده نشد. می‌توانید روی یکی از گزینه‌های آماده کلیک کنید.";
        isVoiceActive = false;
      }
    };

    recognition.onerror = function(event){
      console.warn("Speech recognition error:", event.error);
      isListening = false;
      simulateVoiceInteraction('p1');
    };

    return true;
  }

  const hasNativeSpeech = initSpeechRecognition();

  if(micButton){
    micButton.addEventListener('click', function(){
      if(isVoiceActive || isListening){
        stopVoicePlay();
      } else {
        if(hasNativeSpeech && recognition){
          try {
            recognition.start();
          } catch(e){
            simulateVoiceInteraction('p1');
          }
        } else {
          simulateVoiceInteraction('p1');
        }
      }
    });
  }

  if(stopVoiceBtn){
    stopVoiceBtn.addEventListener('click', stopVoicePlay);
  }

  voicePromptPills.forEach(function(pill){
    pill.addEventListener('click', function(){
      const key = pill.dataset.voicePrompt;
      voicePromptPills.forEach(function(p){ p.classList.toggle('active', p === pill); });
      simulateVoiceInteraction(key);
    });
  });

  voiceSpeedButtons.forEach(function(btn){
    btn.addEventListener('click', function(){
      voiceSpeedButtons.forEach(function(b){ b.classList.toggle('active', b === btn); });
      currentSpeechRate = parseFloat(btn.dataset.voiceSpeed) || 1.0;
      if(currentAudio){
        currentAudio.playbackRate = currentSpeechRate;
      }
      playAudioTone(520, 0.08, 'sine');
    });
  });

  /* ========================================================================
     INTERACTIVE COMPONENT 2: BACKGROUND JOB QUEUE SIMULATOR (V6.9)
     ======================================================================== */
  const addJobBtn = doc.getElementById('add-job-btn');
  const queueTableBody = doc.getElementById('queue-table-body');
  const queueActiveCount = doc.getElementById('queue-active-count');

  if(addJobBtn && queueTableBody){
    let jobCounter = 106;
    addJobBtn.addEventListener('click', function(){
      jobCounter++;
      playAudioTone(700, 0.1, 'sine');
      const tr = doc.createElement('tr');
      tr.className = 'job-row new-job';
      tr.innerHTML = `
        <td><span class="job-id">#JOB-${jobCounter}</span></td>
        <td><strong>تولید ۱۰ مقاله جامع با سئو و تصاویر هوشمند Flux</strong></td>
        <td><span class="job-badge badge-processing"><i class="spinner"></i> در حال پردازش</span></td>
        <td>
          <div class="job-progress"><div class="job-bar" style="width: 15%"></div></div>
        </td>
        <td><small class="job-time">هم‌اکنون</small></td>
      `;
      queueTableBody.insertBefore(tr, queueTableBody.firstChild);
      if(queueActiveCount) queueActiveCount.textContent = toFaNumber(Number(queueActiveCount.dataset.count || 2) + 1);

      // Progress animation
      const bar = tr.querySelector('.job-bar');
      const badge = tr.querySelector('.job-badge');
      const timeSmall = tr.querySelector('.job-time');

      setTimeout(function(){ if(bar) bar.style.width = '65%'; }, 600);
      setTimeout(function(){
        if(bar) bar.style.width = '100%';
        if(badge){
          badge.className = 'job-badge badge-success';
          badge.innerHTML = '✓ تکمیل شد';
        }
        if(timeSmall) timeSmall.textContent = '۱.۲ ثانیه';
        if(queueActiveCount) queueActiveCount.textContent = toFaNumber(Number(queueActiveCount.dataset.count || 2));
        playAudioTone(880, 0.12, 'sine');
      }, 1400);
    });
  }

  /* ========================================================================
     INTERACTIVE COMPONENT 3: ROI & TIME SAVINGS CALCULATOR
     ======================================================================== */
  const calcArticles = doc.getElementById('calc-articles');
  const calcVideos = doc.getElementById('calc-videos');
  const calcSupport = doc.getElementById('calc-support');

  const calcValArticles = doc.getElementById('calc-val-articles');
  const calcValVideos = doc.getElementById('calc-val-videos');
  const calcValSupport = doc.getElementById('calc-val-support');

  const resultHours = doc.getElementById('res-hours');
  const resultCost = doc.getElementById('res-cost');
  const resultRoiDays = doc.getElementById('res-roi-days');

  function updateCalculator(){
    if(!calcArticles || !calcVideos || !calcSupport) return;
    const articles = parseInt(calcArticles.value, 10) || 20;
    const videos = parseInt(calcVideos.value, 10) || 8;
    const support = parseInt(calcSupport.value, 10) || 150;

    if(calcValArticles) calcValArticles.textContent = toFaNumber(articles);
    if(calcValVideos) calcValVideos.textContent = toFaNumber(videos);
    if(calcValSupport) calcValSupport.textContent = toFaNumber(support);

    // Formula:
    // 4.5 hours per comprehensive article + images
    // 5.5 hours per full video script + timeline + SRT
    // 0.25 hours per support ticket
    const totalHours = Math.round(articles * 4.5 + videos * 5.5 + support * 0.25);
    const costSavedToman = totalHours * 160000; // Average team hourly cost
    const dailySaving = costSavedToman / 30;
    const roiDays = Math.max(4, Math.round(15000000 / (dailySaving || 1)));

    if(resultHours) resultHours.textContent = toFaNumber(totalHours);
    if(resultCost) resultCost.textContent = formatToman(costSavedToman) + ' تومان';
    if(resultRoiDays) resultRoiDays.textContent = toFaNumber(roiDays) + ' روز';
  }

  if(calcArticles) calcArticles.addEventListener('input', updateCalculator);
  if(calcVideos) calcVideos.addEventListener('input', updateCalculator);
  if(calcSupport) calcSupport.addEventListener('input', updateCalculator);
  updateCalculator();


  // Interactive Live Pipeline Demo
  const btnRunLiveDemo = doc.getElementById("btn-run-live-demo");
  if(btnRunLiveDemo){
    btnRunLiveDemo.addEventListener("click", function(){
      playAudioTone(660, 0.1, "sine");
      btnRunLiveDemo.textContent = "⏳ در حال پردازش خط لوله...";
      btnRunLiveDemo.disabled = true;
      setTimeout(function(){
        playAudioTone(880, 0.15, "sine");
        btnRunLiveDemo.textContent = "✓ پردازش موفق";
        setTimeout(function(){
          btnRunLiveDemo.textContent = "▶ پردازش مجدد دستور";
          btnRunLiveDemo.disabled = false;
        }, 1200);
      }, 1000);
    });
  }

})();
