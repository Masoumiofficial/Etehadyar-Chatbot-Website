# بسته رسمی و جامع وب‌سایت اتحادیار ۶.۱۲ (Etehadyar Universe OS)

این مخزن شامل نسخه نهایی، مدرن، بدون وابستگی خارجی و بدون نیاز به Build وب‌سایت رسمی **اتحادیار** (سیستم‌عامل هوشمند وردپرس) است که برای انتشار روی دامنه‌های `etehadyar.ir` یا `ai.etehadwp.com` آماده‌سازی شده است.

---

## وضعیت نسخه و تغییرات مهندسی

- **نسخه فعلی پایدار:** `v6.12.0`
- **تعداد کل نسخه‌های اصلی ثبت‌شده:** ۱۱۲ نسخه پایدار + ۱ نسخه آزمایشی (Alpha)
- **پوسته:** طراحی ایرانی مدرن (Modern Iranian Tech UI) با پالت لاجوردی، فیروزه‌ای، مسی و زغالی
- **امکانات تعاملی جدید در لندینگ:**
  1. **دموی تعاملی گفت‌وگوی صوتی پیوسته زنده (Live Voice Playground):** با شبیه‌ساز ضبط صدا، انیمیشن موج صوتی Waveform، کنترل سرعت گویندگی (۰.۸x, ۱.۰x, ۱.۲۵x)، قطع فوری صدا و ضریب اطمینان ۹۸٪.
  2. **کنسول مدیریت صف کارهای نامتقارن و مرکز سلامت (Async Job Queue & Health Center):** شبیه‌سازی پردازش همزمان کارهای سنگین بدون مسدودی سرور (Zero Timeout)، سیستم Retry هوشمند و نمایش امتیاز سلامت ۹۸/۱۰۰.
  3. **ماشین‌حساب هوشمند بازگشت سرمایه (ROI Calculator):** محاسبه بلادرنگ ساعات صرفه‌جویی تیمی و مبالغ ریالی صرفه‌جویی در ماه با اسلایدرهای تعاملی.
  4. **فضاهای کاری ۶‌گانه محصول (Workspaces Tour):** اتاق فرمان، کارخانه محتوای ۷گانه، ویدیو ساز MP4، فروش‌یار ووکامرس، گزارش‌های مدیریتی PDF/XLSX و دستیار صوتی/پشتیبانی.
  5. **تاریخچه جامع تعاملی (Changelog):** با جستجوی بلادرنگ، فیلترهای نسل ۱ تا ۶، کدهای انکر و دسته‌بندی موضوعی.

---

## انتشار روی هاست یا وب‌سرور

محتویات پوشه `etehadyar.ir` را داخل روت هاست (`public_html`) آپلود کنید:

```text
public_html/
├── index.html
├── CHANGELOG.md
├── README-FA.md
├── robots.txt
├── sitemap.xml
├── changelog/
│   └── index.html
└── assets/
    ├── css/
    │   ├── site.css
    │   └── changelog.css
    ├── js/
    │   ├── config.js
    │   ├── site.js
    │   └── changelog.js
    ├── fonts/
    │   ├── estedad-arabic-variable.woff2
    │   ├── estedad-latin-variable.woff2
    │   └── inter-latin-variable.woff2
    ├── icons/
    └── images/
        ├── app-icon.webp
        ├── founder-hero.webp
        ├── brand-cover.webp
        ├── og-cover.jpg
        └── ui/
```

### آدرس‌های صفحات

- **صفحه اصلی:** `https://etehadyar.ir/` (یا `https://ai.etehadwp.com/`)
- **تاریخچه تغییرات (۱۱۲ نسخه):** `https://etehadyar.ir/changelog/`
- **نقشه سایت XML:** `https://etehadyar.ir/sitemap.xml`

---

## تنظیم آدرس‌های خرید و لایسنس

فایل `assets/js/config.js` را باز کرده و لینک‌های نهایی درگاه پرداخت یا تسویه‌حساب را جایگزین فرمایید:

```javascript
window.ETEHADYAR_CONFIG = Object.freeze({
  purchaseUrlIR: "https://etehadyar.ir/checkout/",
  purchaseUrlInternational: "https://etehadyar.ir/checkout-usd/",
  contactUrl: "https://etehadyar.ir/contact/",
  productUrl: "https://etehadyar.ir/",
  priceToman: "۱۵٬۰۰۰٬۰۰۰",
  priceUSD: "150",
  currentVersion: "6.12.0",
  totalReleases: "112"
});
```

---

## مشخصات فنی و سازگاری

- **سازگاری با هسته وردپرس:** WordPress 6.0 به بالا
- **سازگاری با PHP:** نسخه PHP 7.4 تا PHP 8.3+ (سازگار با کلیه هاست‌های اشتراکی ایران)
- **امنیت:** صندوق امنیتی `EAIW_Vault` با الگوریتم AES-256-GCM
- **تبدیل صوت:** پشتیبانی از Web Speech API مرورگر و OpenAI Whisper فارسی
- **بدون وابستگی خارجی:** تمامی فونت‌ها (Estedad و Inter)، تصاویر و اسکریپت‌ها به‌صورت محلی در بسته قرار دارند و بدون نیاز به اینترنت بین‌الملل یا CDN لود می‌شوند.
