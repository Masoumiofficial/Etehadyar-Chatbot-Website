<?php
/**
 * Etehadyar CMS — Backend API Handler (PHP 7.4 - 8.3+)
 * Handles authentication, saving site_data.json and updating config.js on the server.
 */

header('Content-Type: application/json; charset=utf-8');

session_start();

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
$dataFile = __DIR__ . '/../data/site_data.json';
$configFile = __DIR__ . '/../assets/js/config.js';

// Simple Auth Check for protected actions
function isAuthenticated() {
    return isset($_SESSION['etehadyar_admin']) && $_SESSION['etehadyar_admin'] === true;
}

if ($action === 'login') {
    $input = json_decode(file_get_contents('php://input'), true);
    $username = isset($input['username']) ? trim($input['username']) : '';
    $password = isset($input['password']) ? trim($input['password']) : '';

    // Load admin credentials or default
    $adminUser = 'admin';
    $adminPass = 'etehadyar2026';

    $credFile = __DIR__ . '/../data/admin_creds.json';
    if (file_exists($credFile)) {
        $creds = json_decode(file_get_contents($credFile), true);
        if (isset($creds['username'])) $adminUser = $creds['username'];
        if (isset($creds['password'])) $adminPass = $creds['password'];
    }

    if ($username === $adminUser && $password === $adminPass) {
        $_SESSION['etehadyar_admin'] = true;
        echo json_encode(['success' => true, 'message' => 'ورود موفقیت‌آمیز']);
    } else {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'نام کاربری یا رمز عبور نامعتبر است.']);
    }
    exit;
}

if ($action === 'logout') {
    $_SESSION['etehadyar_admin'] = false;
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'خروج موفقیت‌آمیز']);
    exit;
}

if ($action === 'get_data') {
    if (file_exists($dataFile)) {
        echo file_get_contents($dataFile);
    } else {
        echo json_encode(['error' => 'Data file not found']);
    }
    exit;
}

if ($action === 'save_data') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);

    if (!$data || !isset($data['config'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'داده‌های ارسالی نامعتبر است.']);
        exit;
    }

    // 1. Save data/site_data.json
    if (!is_dir(dirname($dataFile))) {
        mkdir(dirname($dataFile), 0755, true);
    }
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // 2. Update assets/js/config.js
    $cfg = $data['config'];
    $purchaseUrlIR = isset($cfg['purchaseUrlIR']) ? $cfg['purchaseUrlIR'] : 'https://etehadyar.ir/';
    $purchaseUrlIntl = isset($cfg['purchaseUrlInternational']) ? $cfg['purchaseUrlInternational'] : 'https://etehadyar.ir/';
    $contactUrl = isset($cfg['contactUrl']) ? $cfg['contactUrl'] : 'https://etehadyar.ir/contact/';
    $productUrl = isset($cfg['productUrl']) ? $cfg['productUrl'] : 'https://etehadyar.ir/';
    $priceToman = isset($cfg['priceToman']) ? $cfg['priceToman'] : '۱۵٬۰۰۰٬۰۰۰';
    $priceUSD = isset($cfg['priceUSD']) ? $cfg['priceUSD'] : '150';
    $currentVersion = isset($cfg['currentVersion']) ? $cfg['currentVersion'] : '6.12.0';
    $totalReleases = isset($cfg['totalReleases']) ? $cfg['totalReleases'] : '112';

    $configJsContent = "/* Etehadyar deployment configuration — auto-updated by Etehadyar CMS */\n" .
        "window.ETEHADYAR_CONFIG = Object.freeze({\n" .
        "  purchaseUrlIR: " . json_encode($purchaseUrlIR, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  purchaseUrlInternational: " . json_encode($purchaseUrlIntl, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  contactUrl: " . json_encode($contactUrl, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  productUrl: " . json_encode($productUrl, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  priceToman: " . json_encode($priceToman, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  priceUSD: " . json_encode($priceUSD, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  currentVersion: " . json_encode($currentVersion, JSON_UNESCAPED_UNICODE) . ",\n" .
        "  totalReleases: " . json_encode($totalReleases, JSON_UNESCAPED_UNICODE) . "\n" .
        "});\n";

    file_put_contents($configFile, $configJsContent);

    echo json_encode([
        'success' => true,
        'message' => 'تغییرات با موفقیت در سرور ذخیره و منتشر شد.',
        'updated_at' => date('Y-m-d H:i:s')
    ]);
    exit;
}

if ($action === 'change_password') {
    $input = json_decode(file_get_contents('php://input'), true);
    $newUser = isset($input['username']) ? trim($input['username']) : 'admin';
    $newPass = isset($input['password']) ? trim($input['password']) : '';

    if (strlen($newPass) < 6) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'رمز عبور باید حداقل ۶ کاراکتر باشد.']);
        exit;
    }

    $credFile = __DIR__ . '/../data/admin_creds.json';
    file_put_contents($credFile, json_encode(['username' => $newUser, 'password' => $newPass], JSON_PRETTY_PRINT));
    echo json_encode(['success' => true, 'message' => 'رمز عبور جدید ذخیره شد.']);
    exit;
}

http_response_code(404);
echo json_encode(['error' => 'Endpoint not found']);
