(function(){
  'use strict';
  const doc = document;

  // DOM Elements
  const authScreen = doc.getElementById('auth-screen');
  const adminApp = doc.getElementById('admin-app');
  const loginForm = doc.getElementById('login-form');
  const loginUser = doc.getElementById('login-user');
  const loginPass = doc.getElementById('login-pass');
  const loginError = doc.getElementById('login-error');
  const btnLogout = doc.getElementById('btn-logout');
  const btnSaveAll = doc.getElementById('btn-save-all');
  const btnRevert = doc.getElementById('btn-revert');
  const adminToast = doc.getElementById('admin-toast');

  // Nav
  const navItems = Array.from(doc.querySelectorAll('.sidebar-nav .nav-item'));
  const tabPanels = Array.from(doc.querySelectorAll('.admin-tab-panel'));
  const tabTitle = doc.getElementById('tab-title');

  // State
  let siteData = null;
  let originalData = null;

  function toFaNumber(value){
    return String(value).replace(/\d/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; });
  }

  function showToast(message){
    if(!adminToast) return;
    adminToast.innerHTML = '<span>' + (message || '✓ تغییرات با موفقیت ذخیره شد.') + '</span>';
    adminToast.classList.add('show');
    setTimeout(function(){ adminToast.classList.remove('show'); }, 3500);
  }

  // Rate Limiting Security Check
  let failedAttempts = parseInt(localStorage.getItem('etehadyar_admin_fails') || '0', 10);
  let lockUntil = parseInt(localStorage.getItem('etehadyar_admin_lock') || '0', 10);

  // Authentication
  function checkAuth(){
    const isLoggedIn = sessionStorage.getItem('etehadyar_admin_logged') === 'true';
    if(isLoggedIn){
      authScreen.style.display = 'none';
      adminApp.style.display = 'grid';
      loadData();
    } else {
      authScreen.style.display = 'flex';
      adminApp.style.display = 'none';
    }
  }

  if(loginForm){
    loginForm.addEventListener('submit', function(e){
      e.preventDefault();
      
      const now = Date.now();
      if(lockUntil && now < lockUntil){
        const remMinutes = Math.ceil((lockUntil - now) / 60000);
        loginError.textContent = `به دلیل تلاش‌های ناموفق مکرر، ورود تا ${remMinutes} دقیقه دیگر مسدود است.`;
        loginError.style.display = 'block';
        return;
      }

      const user = loginUser.value.trim();
      const pass = loginPass.value;
      
      const storedUser = localStorage.getItem('etehadyar_admin_u') || 'admin';
      const storedPass = localStorage.getItem('etehadyar_admin_p') || 'etehadyar2026';

      if(user === storedUser && pass === storedPass){
        sessionStorage.setItem('etehadyar_admin_logged', 'true');
        localStorage.removeItem('etehadyar_admin_fails');
        localStorage.removeItem('etehadyar_admin_lock');
        loginError.style.display = 'none';
        checkAuth();
        showToast('خوش آمدید! وارد پنل مدیریت شدید.');
      } else {
        failedAttempts++;
        localStorage.setItem('etehadyar_admin_fails', String(failedAttempts));
        if(failedAttempts >= 5){
          const lockTime = Date.now() + 15 * 60 * 1000;
          localStorage.setItem('etehadyar_admin_lock', String(lockTime));
          loginError.textContent = 'تعداد دفعات ورود اشتباه بیش از حد مجاز بود. ورود به مدت ۱۵ دقیقه قفل شد.';
        } else {
          loginError.textContent = `نام کاربری یا رمز عبور اشتباه است. (${5 - failedAttempts} تلاش باقیمانده)`;
        }
        loginError.style.display = 'block';
      }
    });
  }

  if(btnLogout){
    btnLogout.addEventListener('click', function(){
      sessionStorage.removeItem('etehadyar_admin_logged');
      checkAuth();
    });
  }

  // Tab Navigation
  navItems.forEach(function(btn){
    btn.addEventListener('click', function(){
      navItems.forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      const targetId = btn.dataset.tab;
      tabPanels.forEach(function(p){ p.classList.toggle('active', p.id === targetId); });
      if(tabTitle) tabTitle.textContent = btn.querySelector('span')?.textContent || 'پیشخوان';
    });
  });

  // Load Data
  function loadData(){
    fetch('../data/site_data.json?v=' + Date.now())
      .then(function(res){ return res.json(); })
      .then(function(data){
        siteData = data;
        originalData = JSON.parse(JSON.stringify(data));
        populateUI();
      })
      .catch(function(err){
        console.warn('Could not fetch site_data.json, loading fallback', err);
        siteData = {
          config: {
            siteName: "اتحادیار",
            siteNameEn: "Etehadyar",
            tagline: "سیستم‌عامل هوشمند وردپرس",
            currentVersion: "6.12.0",
            priceToman: "۱۵٬۰۰۰٬۰۰۰",
            priceUSD: "150",
            purchaseUrlIR: "https://etehadyar.ir/",
            purchaseUrlInternational: "https://etehadyar.ir/",
            totalReleases: "112"
          },
          hero: {
            liveBadgeFa: "نسخه نهایی ۶.۱۲.۰ پایدار · قدرت گرفته از اتحاد وردپرس",
            headlineFa: "فقط یک افزونه نیست؛ سیستم‌عامل هوشمند وردپرس شماست.",
            headlineEn: "Not just a plugin—your AI Operating System for WordPress.",
            descriptionFa: "یک فرمان بده؛ اتحادیار با گفت‌وگوی صوتی زنده فارسی صحبت می‌کند...",
            descriptionEn: "Speak or give a command..."
          },
          faqs: [],
          releases: []
        };
        populateUI();
      });
  }

  function populateUI(){
    if(!siteData) return;

    // Populate KPIs
    const kVer = doc.getElementById('kpi-version');
    const kPrice = doc.getElementById('kpi-price');
    const kRel = doc.getElementById('kpi-releases');
    const kFaq = doc.getElementById('kpi-faqs');
    const badgeRel = doc.getElementById('badge-releases-count');

    if(kVer) kVer.textContent = siteData.config.currentVersion || '6.12.0';
    if(kPrice) kPrice.textContent = (siteData.config.priceToman || '۱۵٬۰۰۰٬۰۰۰') + ' ت';
    if(kRel) kRel.textContent = toFaNumber(siteData.releases ? siteData.releases.length : 112) + ' نسخه';
    if(kFaq) kFaq.textContent = toFaNumber(siteData.faqs ? siteData.faqs.length : 5) + ' مورد';
    if(badgeRel) badgeRel.textContent = toFaNumber(siteData.releases ? siteData.releases.length : 112);

    // Populate Config Tab
    const cfgSitenameFa = doc.getElementById('cfg-sitename-fa');
    const cfgSitenameEn = doc.getElementById('cfg-sitename-en');
    const cfgVersion = doc.getElementById('cfg-version');
    const cfgTaglineFa = doc.getElementById('cfg-tagline-fa');
    const cfgPriceIrr = doc.getElementById('cfg-price-irr');
    const cfgPriceUsd = doc.getElementById('cfg-price-usd');
    const cfgUrlIr = doc.getElementById('cfg-url-ir');
    const cfgUrlIntl = doc.getElementById('cfg-url-intl');

    if(cfgSitenameFa) cfgSitenameFa.value = siteData.config.siteName || '';
    if(cfgSitenameEn) cfgSitenameEn.value = siteData.config.siteNameEn || '';
    if(cfgVersion) cfgVersion.value = siteData.config.currentVersion || '6.12.0';
    if(cfgTaglineFa) cfgTaglineFa.value = siteData.config.tagline || '';
    if(cfgPriceIrr) cfgPriceIrr.value = siteData.config.priceToman || '۱۵٬۰۰۰٬۰۰۰';
    if(cfgPriceUsd) cfgPriceUsd.value = siteData.config.priceUSD || '150';
    if(cfgUrlIr) cfgUrlIr.value = siteData.config.purchaseUrlIR || '';
    if(cfgUrlIntl) cfgUrlIntl.value = siteData.config.purchaseUrlInternational || '';

    // Populate Hero Tab
    const heroBadgeFa = doc.getElementById('hero-badge-fa');
    const heroHeadFa = doc.getElementById('hero-headline-fa');
    const heroDescFa = doc.getElementById('hero-desc-fa');

    if(siteData.hero){
      if(heroBadgeFa) heroBadgeFa.value = siteData.hero.liveBadgeFa || '';
      if(heroHeadFa) heroHeadFa.value = siteData.hero.headlineFa || '';
      if(heroDescFa) heroDescFa.value = siteData.hero.descriptionFa || '';
    }

    renderReleasesTable();
    renderFaqsList();
  }

  // Collect updated UI data into state
  function collectDataFromUI(){
    if(!siteData) return;

    siteData.config.siteName = doc.getElementById('cfg-sitename-fa')?.value || siteData.config.siteName;
    siteData.config.siteNameEn = doc.getElementById('cfg-sitename-en')?.value || siteData.config.siteNameEn;
    siteData.config.currentVersion = doc.getElementById('cfg-version')?.value || siteData.config.currentVersion;
    siteData.config.tagline = doc.getElementById('cfg-tagline-fa')?.value || siteData.config.tagline;
    siteData.config.priceToman = doc.getElementById('cfg-price-irr')?.value || siteData.config.priceToman;
    siteData.config.priceUSD = doc.getElementById('cfg-price-usd')?.value || siteData.config.priceUSD;
    siteData.config.purchaseUrlIR = doc.getElementById('cfg-url-ir')?.value || siteData.config.purchaseUrlIR;
    siteData.config.purchaseUrlInternational = doc.getElementById('cfg-url-intl')?.value || siteData.config.purchaseUrlInternational;
    siteData.config.totalReleases = String(siteData.releases ? siteData.releases.length : 112);

    if(!siteData.hero) siteData.hero = {};
    siteData.hero.liveBadgeFa = doc.getElementById('hero-badge-fa')?.value || siteData.hero.liveBadgeFa;
    siteData.hero.headlineFa = doc.getElementById('hero-headline-fa')?.value || siteData.hero.headlineFa;
    siteData.hero.descriptionFa = doc.getElementById('hero-desc-fa')?.value || siteData.hero.descriptionFa;
  }

  // Render Releases
  function renderReleasesTable(){
    const tbody = doc.getElementById('admin-releases-tbody');
    if(!tbody || !siteData || !siteData.releases) return;

    const searchTerm = (doc.getElementById('admin-search-releases')?.value || '').toLowerCase().trim();
    const filterMajor = doc.getElementById('admin-filter-major')?.value || 'all';

    let html = '';
    siteData.releases.forEach(function(rel, idx){
      const ver = rel.version || '';
      const title = rel.title || '';
      const itemsCount = rel.items ? rel.items.length : 0;
      
      let major = 'other';
      if(ver.startsWith('6.')) major = 'v6';
      else if(ver.startsWith('5.')) major = 'v5';
      else if(ver.startsWith('4.')) major = 'v4';
      else if(ver.startsWith('3.')) major = 'v3';
      else if(ver.startsWith('2.')) major = 'v2';
      else if(ver.startsWith('1.')) major = 'v1';
      else if(rel.is_alpha || ver.includes('alpha')) major = 'alpha';

      if(filterMajor !== 'all' && filterMajor !== major) return;
      if(searchTerm && !ver.toLowerCase().includes(searchTerm) && !title.toLowerCase().includes(searchTerm)) return;

      const isCurrent = (ver === siteData.config.currentVersion);
      const tagBadge = isCurrent
        ? '<span class="badge-tag success">نسخه فعلی</span>'
        : `<span class="badge-tag primary">v${ver}</span>`;

      html += `
        <tr>
          <td>${tagBadge}</td>
          <td><strong>${title}</strong></td>
          <td><small>${toFaNumber(itemsCount)} مورد</small></td>
          <td>
            <button class="btn btn-secondary btn-small" onclick="window.editRelease(${idx})">ویرایش</button>
            <button class="btn btn-danger btn-small" onclick="window.deleteRelease(${idx})">حذف</button>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html || '<tr><td colspan="4" style="text-align:center; padding:30px; color:var(--admin-muted);">نسخه‌ای یافت نشد.</td></tr>';
  }

  const searchRel = doc.getElementById('admin-search-releases');
  const filterRel = doc.getElementById('admin-filter-major');
  if(searchRel) searchRel.addEventListener('input', renderReleasesTable);
  if(filterRel) filterRel.addEventListener('change', renderReleasesTable);

  // Release Modal Actions
  const modalRelease = doc.getElementById('modal-release');
  const formRelease = doc.getElementById('form-release');
  const btnOpenAddRelease = doc.getElementById('btn-open-add-release');

  if(btnOpenAddRelease){
    btnOpenAddRelease.addEventListener('click', function(){
      doc.getElementById('modal-release-title').textContent = 'افزودن نسخه جدید به تاریخچه';
      doc.getElementById('rel-edit-index').value = '-1';
      doc.getElementById('rel-version').value = '';
      doc.getElementById('rel-title').value = '';
      doc.getElementById('rel-items').value = '';
      modalRelease.hidden = false;
    });
  }

  window.editRelease = function(idx){
    const rel = siteData.releases[idx];
    if(!rel) return;
    doc.getElementById('modal-release-title').textContent = 'ویرایش نسخه ' + rel.version;
    doc.getElementById('rel-edit-index').value = String(idx);
    doc.getElementById('rel-version').value = rel.version || '';
    doc.getElementById('rel-title').value = rel.title || '';
    doc.getElementById('rel-items').value = rel.items ? rel.items.map(function(i){ return '- ' + i; }).join('\n') : '';
    modalRelease.hidden = false;
  };

  window.deleteRelease = function(idx){
    const rel = siteData.releases[idx];
    if(!rel) return;
    if(confirm('آیا از حذف نسخه ' + rel.version + ' اطمینان دارید؟')){
      siteData.releases.splice(idx, 1);
      renderReleasesTable();
      populateUI();
      showToast('نسخه حذف شد.');
    }
  };

  if(formRelease){
    formRelease.addEventListener('submit', function(e){
      e.preventDefault();
      const idx = parseInt(doc.getElementById('rel-edit-index').value, 10);
      const ver = doc.getElementById('rel-version').value.trim();
      const title = doc.getElementById('rel-title').value.trim();
      const itemsRaw = doc.getElementById('rel-items').value.split('\n');
      const items = itemsRaw.map(function(l){ return l.replace(/^[-*•]\s*/, '').trim(); }).filter(Boolean);

      const releaseObj = {
        version: ver,
        title: title,
        items: items,
        subsections: [{ title: "", items: items }]
      };

      if(idx >= 0 && siteData.releases[idx]){
        siteData.releases[idx] = releaseObj;
      } else {
        siteData.releases.unshift(releaseObj);
      }

      modalRelease.hidden = true;
      renderReleasesTable();
      populateUI();
      showToast('اطلاعات نسخه ثبت شد.');
    });
  }

  // Render FAQs
  function renderFaqsList(){
    const container = doc.getElementById('admin-faqs-list');
    if(!container || !siteData || !siteData.faqs) return;

    let html = '';
    siteData.faqs.forEach(function(faq, idx){
      html += `
        <div class="admin-card" style="margin-bottom:0; padding:18px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
            <div style="flex:1;">
              <strong style="color:#38bdf8; font-size:15px;">${idx + 1}. ${faq.questionFa}</strong>
              <p style="margin:6px 0 0; color:#cbd5e1; font-size:13.5px;">${faq.answerFa}</p>
            </div>
            <div style="display:flex; gap:6px; flex:none;">
              <button class="btn btn-secondary btn-small" onclick="window.editFaq(${idx})">ویرایش</button>
              <button class="btn btn-danger btn-small" onclick="window.deleteFaq(${idx})">حذف</button>
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = html || '<p style="color:var(--admin-muted); text-align:center;">هیچ سوالی ثبت نشده است.</p>';
  }

  const modalFaq = doc.getElementById('modal-faq');
  const formFaq = doc.getElementById('form-faq');
  const btnOpenAddFaq = doc.getElementById('btn-open-add-faq');

  if(btnOpenAddFaq){
    btnOpenAddFaq.addEventListener('click', function(){
      doc.getElementById('modal-faq-title').textContent = 'افزودن سوال متداول جدید';
      doc.getElementById('faq-edit-index').value = '-1';
      doc.getElementById('faq-q-fa').value = '';
      doc.getElementById('faq-a-fa').value = '';
      doc.getElementById('faq-q-en').value = '';
      doc.getElementById('faq-a-en').value = '';
      modalFaq.hidden = false;
    });
  }

  window.editFaq = function(idx){
    const faq = siteData.faqs[idx];
    if(!faq) return;
    doc.getElementById('modal-faq-title').textContent = 'ویرایش سوال متداول';
    doc.getElementById('faq-edit-index').value = String(idx);
    doc.getElementById('faq-q-fa').value = faq.questionFa || '';
    doc.getElementById('faq-a-fa').value = faq.answerFa || '';
    doc.getElementById('faq-q-en').value = faq.questionEn || '';
    doc.getElementById('faq-a-en').value = faq.answerEn || '';
    modalFaq.hidden = false;
  };

  window.deleteFaq = function(idx){
    if(confirm('آیا از حذف این سوال متداول اطمینان دارید؟')){
      siteData.faqs.splice(idx, 1);
      renderFaqsList();
      populateUI();
      showToast('سوال متداول حذف شد.');
    }
  };

  if(formFaq){
    formFaq.addEventListener('submit', function(e){
      e.preventDefault();
      const idx = parseInt(doc.getElementById('faq-edit-index').value, 10);
      const qFa = doc.getElementById('faq-q-fa').value.trim();
      const aFa = doc.getElementById('faq-a-fa').value.trim();
      const qEn = doc.getElementById('faq-q-en').value.trim();
      const aEn = doc.getElementById('faq-a-en').value.trim();

      const faqObj = {
        id: 'faq-' + (idx >= 0 ? idx + 1 : siteData.faqs.length + 1),
        questionFa: qFa,
        answerFa: aFa,
        questionEn: qEn,
        answerEn: aEn
      };

      if(idx >= 0 && siteData.faqs[idx]){
        siteData.faqs[idx] = faqObj;
      } else {
        siteData.faqs.push(faqObj);
      }

      modalFaq.hidden = true;
      renderFaqsList();
      populateUI();
      showToast('سوال متداول ثبت شد.');
    });
  }

  // Save All Changes
  if(btnSaveAll){
    btnSaveAll.addEventListener('click', function(){
      collectDataFromUI();

      fetch('api.php?action=save_data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(siteData)
      })
      .then(function(res){ return res.json(); })
      .then(function(result){
        showToast('✓ تمام تغییرات با موفقیت در سرور ذخیره و منتشر شدند.');
      })
      .catch(function(err){
        localStorage.setItem('etehadyar_site_data', JSON.stringify(siteData));
        showToast('✓ تغییرات در حافظه ذخیره شد. برای انتشار می‌توانید بسته زیپ را دانلود کنید.');
      });
    });
  }

  // Revert Changes
  if(btnRevert){
    btnRevert.addEventListener('click', function(){
      if(confirm('آیا مایل به بازگردانی تغییرات ذخیره‌نشده هستید؟')){
        siteData = JSON.parse(JSON.stringify(originalData));
        populateUI();
        showToast('تغییرات بازگردانی شد.');
      }
    });
  }

  // Export JSON Backup
  const btnExportJson = doc.getElementById('btn-export-json');
  if(btnExportJson){
    btnExportJson.addEventListener('click', function(){
      collectDataFromUI();
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(siteData, null, 2));
      const downloadAnchor = doc.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "site_data_backup_" + (siteData.config.currentVersion || '6.12') + ".json");
      doc.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    });
  }

  // Import JSON Backup
  const btnImportJson = doc.getElementById('btn-import-json');
  if(btnImportJson){
    btnImportJson.addEventListener('change', function(e){
      const file = e.target.files[0];
      if(!file) return;
      const reader = new FileReader();
      reader.onload = function(evt){
        try {
          const parsed = JSON.parse(evt.target.result);
          if(parsed && parsed.config){
            siteData = parsed;
            populateUI();
            showToast('✓ دیتای پشتیبان با موفقیت بارگذاری شد.');
          } else {
            alert('فرمت فایل نامعتبر است.');
          }
        } catch(err){
          alert('خطا در خواندن فایل JSON: ' + err.message);
        }
      };
      reader.readAsText(file);
    });
  }

  // Download Site Zip
  const btnDownloadZip = doc.getElementById('btn-download-zip');
  if(btnDownloadZip){
    btnDownloadZip.addEventListener('click', function(){
      window.location.href = '../etehadyar-v6.12.0-final.zip';
    });
  }

  // Change Password
  const formChangePass = doc.getElementById('form-change-password');
  if(formChangePass){
    formChangePass.addEventListener('submit', function(e){
      e.preventDefault();
      const newU = doc.getElementById('new-admin-user').value.trim();
      const newP = doc.getElementById('new-admin-pass').value;
      if(newP.length < 6){
        alert('رمز عبور باید حداقل ۶ کاراکتر باشد.');
        return;
      }
      localStorage.setItem('etehadyar_admin_u', newU);
      localStorage.setItem('etehadyar_admin_p', newP);
      showToast('✓ نام کاربری و رمز عبور جدید با موفقیت ذخیره شد.');
    });
  }

  checkAuth();
})();
